
void libraryCLI( char *bookFile );

void initLibrary( char *bookFile, Library *theLibrary );
int readBooks( FILE *books, Book *bookList );

void exitLibrary( Library *theLibrary );

