package comp1721.cwk1;


public class WordList {
  // TODO: Implement constructor with a String parameter

  // TODO: Implement size() method, returning an int

  // TODO: Implement getWord() with an int parameter, returning a String
}
