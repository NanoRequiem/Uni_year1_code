package comp1721.cwk1;

import java.util.Scanner;


public class Guess {
  // Use this to get player input in readFromPlayer()
  private static final Scanner INPUT = new Scanner(System.in);

  // TODO: Implement constructor with int parameter

  // TODO: Implement constructor with int and String parameters

  // TODO: Implement getGuessNumber(), returning an int

  // TODO: Implement getChosenWord(), returning a String

  // TODO: Implement readFromPlayer()

  // TODO: Implement compareWith(), giving it a String parameter and String return type

  // TODO: Implement matches(), giving it a String parameter and boolean return type
}
