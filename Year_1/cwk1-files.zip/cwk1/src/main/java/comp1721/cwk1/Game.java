package comp1721.cwk1;


public class Game {
  // TODO: Implement constructor with String parameter

  // TODO: Implement constructor with int and String parameters

  // TODO: Implement play() method

  // TODO: Implement save() method, with a String parameter
}
